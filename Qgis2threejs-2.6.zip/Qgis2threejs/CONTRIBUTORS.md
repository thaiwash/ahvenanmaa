Contributors
------------

Many thanks to all the contributors!

* Célian https://github.com/kostar111
* Olivier Dalang https://github.com/olivierdalang
* Josef K https://github.com/jkall
* Luca Casagrande https://github.com/lucacasagrande
* Stefano Cudini https://github.com/stefanocudini
* Steven Sabo https://github.com/DigDigDig
* João Gaspar https://github.com/jonnyforestGIS
